RBN MUSIC demo website

HOW TO USE
1. Open index.html in a web browser to preview.
2. To publish free, create a GitHub account, create a public repository, upload index.html, then enable GitHub Pages in repository Settings > Pages (Deploy from a branch, main, /root). Another easy option is Netlify Drop: upload the folder/site file on Netlify's deploy page.
3. The Roben FM button opens the stream URL the owner shared. An embedded player needs a supported HTTPS player/stream URL from the radio host.
4. To add songs, edit index.html and find `const songs = [` near the bottom. Add entries like:
{title:"My Song", artist:"H Morgan", genre:"Amapiano", audioUrl:"https://your-authorized-audio-url/song.mp3", cover:"🎵"}
Only add music you own or have permission to distribute.
5. The submission form is a demo: it prepares text for copying but does not send or upload files. For a live site, connect a form service/backend.
